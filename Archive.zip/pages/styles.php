    <link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/animate.min.css" rel="stylesheet"/>
    <link href="/assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
		<link href="/assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <link href="/assets/bootstrap-datetimepicker/css/bootstrap-datetimepicker-standalone.css" rel="stylesheet">
    <link href="/assets/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
