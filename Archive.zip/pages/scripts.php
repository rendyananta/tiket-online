<script src="/assets/js/jquery.min.js" type="text/javascript"></script>
<script src="/assets/js/moment-with-locales.min.js"></script>
<script src="/assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="/assets/js/bootstrap-notify.js"></script>
<script src="/assets/js/light-bootstrap-dashboard.js"></script>
<script src="/assets/js/app.js"></script>
<?php require_once './pages/notify.php' ?>
