<?php
return [
  'server' => '127.0.0.1:8000',
  'host' => '127.0.0.1',
  'dbname' => 'tiket_online',
  'username' => 'root',
  'password' => '3426'
];
