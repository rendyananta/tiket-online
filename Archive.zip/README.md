## LOGIN ##
* /staff-masuk
* /admin-masuk

### Akun ###

#### ADMIN ####
username : admin
password : admin123

#### STAFF ####
username : staff
password : staff123


> Disarankan Membuka Web di root directory web servver
